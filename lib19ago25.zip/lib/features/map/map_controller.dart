// Placeholder para evoluir controle do mapa (listeners, raio 1000m, etc.)
class GameMapController {
  // No futuro: listeners de Firestore por geohash, centralização, etc.
}